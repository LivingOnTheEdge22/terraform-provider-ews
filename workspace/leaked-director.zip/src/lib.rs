// Enable Imperva to provide custom functions that are only supported by us from our proprietary wasm worker
use wasm_bindgen::prelude::*;

// Enables us to use Rust's standard library
use std::env;

// // Define the methods that will be provided natively by Imperva
// // This wasm binding generator, generates the bindings for us
// #[wasm_bindgen]
// extern {
//     // We define that Imperva will provide I/O capabilities here as wasm allows for native bindings
//     pub fn http_get(url: &str) -> &str;
// }

fn http_post(_url: *const str, _body: *const String) -> &'static str {
    return "leaked";
}

fn leaked_checker(username: &str, password: &str) -> *const str {

    println!("Username is : {:?}, Password is :{:?}", username, password);
    let post_body: &String = &format!("{}:{}", username, password);
    let leaked_result = http_post("https://ews.abp-monsters.com/api/v1/run/check-leaked?accountId=-1", post_body);
    return if leaked_result.contains("LEAKED") {
        "301 REDIRECT /reset"
    } else {
        "NONE"
    }
}

fn main() {

    let result = leaked_checker("leaked1", "pass1");
    println!("{:?}", result);

}
