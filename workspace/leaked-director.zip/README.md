### Leaked-Checker 

- Business logic written in Rust to determine if a login has to be forwarded to the password reset page

### Dependencies 

- On Mac run ```brew install wasm-pack``` (Used to compile to wasm)
- ```brew install wasmtime```

### To Build 

- ```wasm-pack build --target web``` 
- The build is in ```./pkg```


### To run 

- ```wasmtime run ./pkg/leaked_redirector_bg.wasm test_user_1 test_password_1```

### To zip the contents 

- ```zip -r leaked-redirector.zip ./```

