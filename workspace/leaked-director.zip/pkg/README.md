### Leaked-Checker 

- Business logic written in Rust to determine if a login has to be forwarded to the password reset page

